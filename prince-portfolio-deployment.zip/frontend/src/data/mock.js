const mockData = {
  profile: {
    name: "Prince Pal",
    title: "Civil Engineer & Entrepreneur",
    tagline: "Experienced civil engineer with expertise in large-scale infrastructure projects and a passion for innovative business solutions. Currently leading construction projects while building the next generation of e-commerce platforms.",
    about: "I am a results-driven civil engineer with hands-on experience in major infrastructure projects, including work with Larsen & Toubro on India's fastest railway project. My journey combines technical excellence in civil engineering with entrepreneurial vision, having founded and managed an e-commerce fashion startup. I thrive at the intersection of engineering precision and business innovation, bringing systematic problem-solving skills to every challenge.",
    photos: [
      {
        url: "https://customer-assets.emergentagent.com/job_tech-profile-39/artifacts/lcrsyd3l_IMG_20250327_205949_179.webp",
        alt: "Prince Pal - Professional Photo",
        caption: "At a historic landmark"
      },
      {
        url: "https://customer-assets.emergentagent.com/job_tech-profile-39/artifacts/qb8lbwqd_IMG_20250911_083216_708.webp",
        alt: "Prince Pal - Casual Photo",
        caption: "Professional headshot"
      }
    ]
  },
  
  contact: {
    email: "palprince27112005@gmail.com",
    phone: "+91 8923112931",
    location: "Gurgaon, India"
  },
  
  skills: [
    {
      category: "Technical Skills",
      items: [
        { name: "AutoCAD", level: 90 },
        { name: "Project Management", level: 85 },
        { name: "Construction Planning", level: 80 },
        { name: "Quality Control", level: 75 },
        { name: "Site Supervision", level: 85 }
      ]
    },
    {
      category: "Business Skills",
      items: [
        { name: "E-commerce Management", level: 75 },
        { name: "Sales & Marketing", level: 80 },
        { name: "Team Leadership", level: 85 },
        { name: "Strategic Planning", level: 70 },
        { name: "Client Relations", level: 80 }
      ]
    },
    {
      category: "Software & Tools",
      items: [
        { name: "MS Office Suite", level: 85 },
        { name: "Project Planning Software", level: 75 },
        { name: "E-commerce Platforms", level: 70 },
        { name: "Digital Marketing Tools", level: 65 }
      ]
    }
  ],
  
  experience: [
    {
      position: "Junior Civil Engineer",
      company: "Feetinch Studio LLP",
      location: "Sohna, Gurgaon",
      period: "Apr 2025 - Present",
      description: "Leading civil engineering activities for The Leaf Mall construction project in Sohna, Gurgaon. This major commercial development consists of 14 floors and 2 basements with mixed-use retail, recreational spaces, hotel, and office components. The project features unique leaf-inspired architecture and is pre-certified GOLD by IGBC.",
      achievements: [
        "Successfully managing multi-floor commercial construction project with green building standards",
        "Ensuring compliance with IGBC GOLD certification requirements and building codes",
        "Coordinating with multiple contractor teams and suppliers for integrated development",
        "Implementing quality control measures throughout construction phases for mixed-use facility"
      ]
    },
    {
      position: "Civil Engineer",
      company: "Larsen & Toubro Limited",
      location: "Vadodara",
      period: "Sep 2024 - Mar 2025",
      description: "Worked on the Mumbai-Ahmedabad High-Speed Rail (MAHSR) project, India's first bullet train corridor. Focused on bridge construction and steel fabrication including prestressed concrete (PSC) bridges and steel truss bridges. Handled 70-meter-long open web girder (OWG) steel bridges weighing over 674 metric tonnes.",
      achievements: [
        "Contributed to India's first high-speed railway infrastructure project supporting 320 km/h speeds",
        "Managed steel fabrication and installation for multiple bridge types along 237.1 km corridor",
        "Ensured adherence to Japanese Shinkansen technology standards and safety protocols",
        "Collaborated with international teams on cutting-edge railway infrastructure development"
      ]
    },
    {
      position: "Civil Engineering Intern",
      company: "Public Works Department (P.W.D.)",
      location: "Bareilly",
      period: "Jul 2023 - Aug 2023",
      description: "Gained practical experience in government infrastructure projects, learning about public sector construction processes, documentation, and quality standards. Worked on various municipal and state infrastructure development projects.",
      achievements: [
        "Learned government project documentation and approval processes for public infrastructure",
        "Assisted in site surveys and quality inspections for municipal construction projects",
        "Developed understanding of public infrastructure standards and compliance requirements",
        "Gained exposure to large-scale government construction projects and procurement processes"
      ]
    }
  ],
  
  projects: [
    {
      title: "The Leaf Mall Construction",
      subtitle: "14-Floor Multi-Use Commercial Development",
      type: "Engineering",
      description: "Leading the civil engineering aspects of The Leaf Mall, a major commercial development project in Sohna, Gurgaon. This project features 14 floors and 2 basement levels with mixed-use retail, recreational spaces, hotel, and office components. The mall has a unique leaf-inspired architectural design with glass facades and is pre-certified GOLD by the Indian Green Building Council (IGBC).",
      technologies: ["AutoCAD", "Project Management", "Quality Control", "Site Supervision", "Green Building Standards"],
      status: "In Progress",
      impact: "Major commercial development contributing to Sohna-Gurgaon infrastructure growth",
      company: "Feetinch Studio LLP",
      location: "Sohna, Gurgaon",
      image: "https://images.unsplash.com/photo-1643580018337-5af73fe3c21a?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDJ8MHwxfHNlYXJjaHwzfHxjb21tZXJjaWFsJTIwbWFsbCUyMGNvbnN0cnVjdGlvbnxlbnwwfHx8fDE3NTg1MDAzNjZ8MA&ixlib=rb-4.1.0&q=85"
    },
    {
      title: "Mumbai-Gujarat High-Speed Railway Bridge",
      subtitle: "Bullet Train Infrastructure Project",
      type: "Engineering",
      description: "Contributed to India's ambitious Mumbai-Ahmedabad High-Speed Rail (MAHSR) project with Larsen & Toubro, focusing on bridge construction and steel fabrication. Worked on prestressed concrete (PSC) bridges and steel truss bridges along the 237.1 km corridor, including 70-meter-long open web girder (OWG) steel bridges weighing over 674 metric tonnes.",
      technologies: ["Steel Fabrication", "Bridge Construction", "Safety Management", "Team Coordination", "High-Speed Rail Infrastructure"],
      status: "Completed",
      impact: "Critical infrastructure for India's first bullet train corridor supporting 320 km/h speeds",
      company: "Larsen & Toubro Limited",
      location: "Vadodara, Gujarat",
      image: "https://images.unsplash.com/photo-1630709658737-68a1c8d72837?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzl8MHwxfHNlYXJjaHwxfHxyYWlsd2F5JTIwYnJpZGdlJTIwY29uc3RydWN0aW9ufGVufDB8fHx8MTc1ODUwMDM3Mnww&ixlib=rb-4.1.0&q=85"
    },
    {
      title: "E-commerce Fashion Startup",
      subtitle: "Digital Fashion Platform",
      type: "Business",
      description: "Founded and developed a fashion e-commerce platform, handling everything from website creation to marketing strategy implementation. This venture combines technical website development with business strategy and customer acquisition, demonstrating entrepreneurial skills alongside engineering expertise.",
      technologies: ["E-commerce Platform", "Digital Marketing", "Sales Strategy", "Customer Relations", "Business Development"],
      status: "Active",
      impact: "Building innovative online fashion retail experience with focus on customer engagement",
      company: "Independent Venture",
      location: "India",
      image: "https://images.unsplash.com/photo-1754373218882-a9fbc0921e0f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDJ8MHwxfHNlYXJjaHw0fHxjb21tZXJjaWFsJTIwbWFsbCUyMGNvbnN0cnVjdGlvbnxlbnwwfHx8fDE3NTg1MDAzNjZ8MA&ixlib=rb-4.1.0&q=85"
    },
    {
      title: "Public Infrastructure Development",
      subtitle: "Government Sector Experience",
      type: "Engineering",
      description: "Gained comprehensive experience in public sector construction during internship with Public Works Department (P.W.D.), Bareilly. Learned government processes, documentation requirements, and public infrastructure standards while working on various municipal and state infrastructure projects.",
      technologies: ["Government Compliance", "Documentation", "Quality Standards", "Site Survey", "Public Infrastructure"],
      status: "Completed",
      impact: "Contributing to public infrastructure development and understanding government construction processes",
      company: "Public Works Department (P.W.D.)",
      location: "Bareilly, UP",
      image: "https://images.unsplash.com/photo-1748618439948-1fe6d0d4e289?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzl8MHwxfHNlYXJjaHwyfHxyYWlsd2F5JTIwYnJpZGdlJTIwY29uc3RydWN0aW9ufGVufDB8fHx8MTc1ODUwMDM3Mnww&ixlib=rb-4.1.0&q=85"
    }
  ],
  
  certificates: [
    {
      title: "Generative AI Mastermind",
      organization: "Outskill",
      issuer: "Vaibhav Sisinty, Founder - Outskill",
      date: "2024",
      type: "Professional Development",
      description: "Successfully completed comprehensive training in Generative AI technologies, mastering cutting-edge AI tools and applications for business and technical innovation.",
      category: "AI & Technology",
      skills: ["Generative AI", "AI Applications", "Technology Innovation", "Digital Transformation"],
      credentialUrl: "https://customer-assets.emergentagent.com/job_tech-profile-39/artifacts/g3ph0deu_IMG_20250922_053704.jpg"
    }
  ],

  achievements: [
    {
      title: "Event Management Leadership",
      description: "Joint Event Coordinator for Annual Function and Event Coordinator for Fresher Party",
      category: "Leadership"
    },
    {
      title: "Academic Excellence",
      description: "Completed Diploma in Civil Engineering with 70% marks",
      category: "Education"
    },
    {
      title: "Industry Experience",
      description: "Successfully transitioned from internship to full-time roles in major construction companies",
      category: "Professional"
    },
    {
      title: "AI Technology Certification",
      description: "Completed Generative AI Mastermind certification from Outskill",
      category: "Professional Development"
    }
  ]
};

export default mockData;